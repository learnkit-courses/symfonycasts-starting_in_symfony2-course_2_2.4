This directory contains some templates and CSS
files that are copied in during the screencast:

1) Event - these are the template files that are copied
   into the EventBundle/Resources/views directory after generating
   the CRUD for the Event entity.

2) public - these are the CSS and image files that
   are copied into the EventBundle/Resources directory
   also during the code generation chapter.
