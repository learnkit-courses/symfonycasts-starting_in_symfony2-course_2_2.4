<?php

namespace Yoda\EventBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EventBundle extends Bundle
{
}
